<?php 
	
	$angka = 15;


	echo "aku adalah angka ". $angka. "<br>";
	echo " <br> jika aku dikali 5 maka, aku sekarang bernilai " .($angka*=5); //75
	echo " <br> jika aku dibagi 3 maka, aku sekarang bernilai " .($angka/=3); //25
	echo " <br> jika aku dikurang 30 maka, aku sekarang bernilai " .($angka-=30); //-5
	echo " <br> jika aku ditambah 10 maka, aku sekarang bernilai " .($angka+=10); //5
?>